<!DOCTYPE html>
<?php
	require('control_session.php');//vérifie si on est bien connecté
?>

<html>
	
    <head>
        <title>Accueil PCHER</title>
		<link rel="stylesheet" href="style2.css" />
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
		
		<script>
			function big(x) {
				x.style.height = "110%";
				x.style.width = "110%";
			}
			
			function normalImg(x) {
				x.style.height = "auto";
				x.style.width = "auto";
			}
		</script>

		<style>
			.carousel-inner > .item > img,
			.carousel-inner > .item > a > img 
			{
				width: 70%;
				margin: auto;
			}
		</style>
		
    </head>
	
    <body>
		
        <h1>
			PCHER, LE SITE DES PRODUITS PAS CHER !
        </h1>
		<br />
		<nav>
            <ul>
                <li><a href="PCHER_accueil.php">Accueil</a></li>
                <li><a href="QuiSommeNous.php">Qui sommes-nous ?</a></li>
				<li><a href="chat.php">Salon de discussion</a></li>
                <li><a href="contact.php">Contact</a></li>
				<li><a href="/projet2_PW/PCHER_deconnexion.php">Déconnexion</a></li>
            </ul>
        </nav>
		
		<center>
		<?php
				echo "<p style='color:red; font-family:arial black, Charcoal, sans-serif ; font-size:30px;'>Bonjour et bienvenue ".$_SESSION['login']."</p>";
		?>
		</center>
		<br />
		
		<div class="container">
			<div id="myCarousel" class="carousel slide" data-ride="carousel">
   
				<ol class="carousel-indicators">
					<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
					<li data-target="#myCarousel" data-slide-to="1"></li>
					<li data-target="#myCarousel" data-slide-to="2"></li>
					<li data-target="#myCarousel" data-slide-to="3"></li>
					<li data-target="#myCarousel" data-slide-to="4"></li>
					<li data-target="#myCarousel" data-slide-to="5"></li>
				</ol>

				<div class="carousel-inner" role="listbox">
		
					<div class="item active">
						<a href="achatI.php"> <img onmouseover="big(this)" onmouseout="normalImg(this)" src="contents2/iphone1.jpg" height="40" width="30" alt="iphone"/> </a>
						<div class="carousel-caption">
							<h3 style="color:yellow"> 300€ !</h3>
							<p style="color:yellow">Cliquez sur l'image pour acheter</p>
						</div>
					</div>
					
					<div class="item">
						<a href="achatW.php"> <img onmouseover="big(this)" onmouseout="normalImg(this)" src="contents2/watch.png"  alt="Apple watch 2"/> </a>
						<div class="carousel-caption">
							<h3 style="color:yellow"> 50 € !</h3>
							<p style="color:yellow">Cliquez sur l'image pour acheter</p>
						</div>
					</div>
					
					<div class="item">
						<a href="achatS.php"> <img onmouseover="big(this)" onmouseout="normalImg(this)" src="contents2/samsungS6.jpg"  alt="Samsung galaxy s6 edge +"/> </a>
						<div class="carousel-caption">
							<h3 style="color:yellow"> 300 € !</h3>
							<p style="color:yellow">Cliquez sur l'image pour acheter</p>
						</div>
					</div>
					
					<div class="item">
						<a href="achatC.php"><img onmouseover="big(this)" onmouseout="normalImg(this)" src="contents2/ps4.jpg" alt="ps4"/></a>
						<div class="carousel-caption">
							<h3 style="color:yellow"> 200€ !</h3>
							<p style="color:yellow">Cliquez sur l'image pour acheter</p>
						</div>
					</div>
					
					<div class="item">
						<a href="achatT.php"> <img onmouseover="big(this)" onmouseout="normalImg(this)" src="contents2/LG-and-OLED.jpg"  alt="Tv Lg OLed"/> </a>
						<div class="carousel-caption">
							<h3 style="color:yellow"> 1000 € !</h3>
							<p style="color:yellow">Cliquez sur l'image pour acheter</p>
						</div>
					</div>
					
					<div class="item">
						<a href="achatG.php"><img onmouseover="big(this)" onmouseout="normalImg(this)" src="contents2/golf1.jpg" alt="golf" /></a>
						<div class="carousel-caption">
							<h3 style="color:yellow"> 3 000€ !</h3>
							<p style="color:yellow">Cliquez sur l'image pour acheter</p>
						</div>
					</div>
  
				</div>

				<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
					<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				
				<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
					<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
				
			</div>
		</div>
		<br />
		<p>
			Pourquoi revendre nos produits à des prix fous ? Tout simplement, pour attirer des clients afin de commencer notre extension commerciale et être reconnu dans le monde.
			<br />
			Vous ne trouverez nul part nos produits à ces prix-là, alors profitez-en car nos premiers clients bénéficieront de nos réductions maximales.
			<br /><br />
			<i>* <u>Informations à savoir avant vos achats</u> :</i>
			<br />
			Après avoir confirmer votre adresse e-mail, vous recevrez un mail contenant toutes les instructions concernant
			la méthode pour consulter le produit via une vidéo conférence <a href="http://www.skype.com/fr/download-skype/skype-for-computer/" title="Cliquez pour connaître et télécharger Skype">Skype</a> ou
			sur place.
			<br />
			Si le produit vous satisfait, nous vous invitons à <a href="contents2/relais.jpg" title="Cliquez pour voir nos points de relais">un point de relais</a> pour récupérer votre produit et régler votre achat par espèce ou chèque.
			<br />
			Ainsi, votre achat sera 100% sécurisé.
			<br /><br /> 
			Nombre de visiteurs : <script src="http://webdezign.tutoriaux.free.fr/services/compteur_page.php?client=85439&Af=10"> </script>
			<br />
		</p>
    </body>
</html>