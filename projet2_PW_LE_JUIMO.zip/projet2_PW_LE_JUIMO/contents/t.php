<!DOCTYPE html>
<?php
	require('control_session.php');//vérifie si on est bien connecté
?>
<html>

	<head>
		<title>
		TROLL PCHER
		</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="style3.css" />
		<link rel="icon" type="image/jpeg" href="http://www.journaldugeek.com/files/2013/09/05386305-photo-troll-face1.jpg" />
		
		<script>
		function clign()
			{ 
				current = document.getElementById('t').style.visibility; 
				
				if(current == 'hidden')
					newCurrent = 'visible'; 
				else
					newCurrent = 'hidden'; 
					
				document.getElementById('t').style.visibility = newCurrent; 
			} 
			setInterval('clign();', 800);
		</script>
	</head>
	
	<body class="b">
		<h1 class="t">
			VOUS VOUS ETES FAIT AVOIR !
		</h1>
		
		<img id="t" class="i" src="contents2/t.jpg" style="width:800px;height:429px;" alt="troll"/> 
		
		<p>
			Vous venez de perdre un temps précieux de votre vie et nous en sommes très fières.
			<br />
			Merci quand même d'avoir visité notre site web.
			<br /> <br />
			<a href="PCHER_accueil.php" title="Cliquez pour revenir à notre page d'accueil">Revenir à la page d'accueil </a>
		</p>
		<audio src="contents2/t.mp3" autoplay></audio>
	</body>
	
</html>