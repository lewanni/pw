//rafraichit auto les messages du chat avec AJAX

function timer() { //actualise toutes les secondes
	comp=(setTimeout("refresh()",1000));
}

function getXhr() {
	var xhr = null;
	if(window.XMLHttpRequest) // Firefox ou autres
		xhr = new XMLHttpRequest();
	else if(window.ActiveXObject){ // si c'est internet explorer : active activeX
		try {
			xhr = new ActiveXObject("Msxml2.XMLHTTP"); //IE7 ou plus
		} catch (e) {
			xhr = new ActiveXObject("Microsoft.XMLHTTP"); //IE6 ou moins
		}
	} else { // XMLHttpRequest non supporté par le navigateur
		alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest...");
		xhr = null;
	}
	return xhr; //retourne l'objet 
}

function refresh() {
	var xhr = getXhr()
	// On défini ce qu'on va faire quand on aura la réponse
	xhr.onreadystatechange = function() { // si on a tout reçu et que le serveur est ok : alors on récupère les données (xhr.responseText) qu'on injecte entre les balises div du chat
		if(xhr.readyState == 4 && xhr.status == 200) {
			var html = xhr.responseText;
			document.getElementById('chat').innerHTML = html;
		}
	}
	xhr.open("GET","chat_message.php",true); //ouvre une conenxion en méthode get vers message.php
	xhr.send(null); //on envoie
	setTimeout('refresh()',1000); //fréquence
}