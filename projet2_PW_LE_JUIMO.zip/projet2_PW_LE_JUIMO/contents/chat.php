<!DOCTYPE html>
<?php
	require('control_session.php');//vérifie si on est bien connecté
	// Connexion à la base de donnée pcher
	try {
		$bdd = new PDO('mysql:host=localhost;dbname=pcher;charset=utf8', 'root', '');
	}
	catch(Exception $e) {
			die('Erreur : '.$e->getMessage());
	}
	
	if(isset($_POST['envoyer'])) {
		if(!empty($_POST['message'])) {
			$message_taille = strlen($_POST['message']);
			if($message_taille <=500) { //si message ne dépasse pas 200 caractères
				// Insertion du message à l'aide d'une requête préparée
				$req = $bdd->prepare('INSERT INTO chat (login, message, date) VALUES(?,?, NOW())');
				$req->execute(array($_SESSION['login'], $_POST['message']));
				// Redirection vers page d'accueil après l'envoi du message
				header('Location: chat.php');
			} else
				echo "
					<script>
						alert(\"Votre message ne doit pas dépasser 500 caractères.\");
						window.location.replace('chat.php');
					</script>";
		} else
			echo "
					<script>
						alert(\"Le champ message est vide. Remplissez-le.\");
						window.location.replace('chat.php');
					</script>";
	}
?>

<html>
    <head>
        <title>Salon de discusion PCHER</title>
		<link rel="stylesheet" href="style2.css" />
		<meta charset="utf-8">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<script type="text/javascript" src="chat.js"></script> <!--Rafraichi toutes les secondes les messages du chat -->
    </head>
	
    <body class="c" onload="refresh()">
        <h1>
			PCHER, LE SITE DES PRODUITS PAS CHER !
        </h1>
		<br />
		<nav>
            <ul>
                <li><a href="PCHER_accueil.php">Accueil</a></li>
                <li><a href="QuiSommeNous.php">Qui sommes-nous ?</a></li>
				<li><a href="chat.php">Salon de discussion</a></li>
                <li><a href="contact.php">Contact</a></li>
				 <li><a href="/projet2_PW/PCHER_deconnexion.php">Déconnexion</a></li>
            </ul>
        </nav>
		<div class="chat" id="chat"></div>
		<div class="chat">
			<form action="" method="post">
				<p>
					<table>
						<tr>
							<td> 
								<label for="message">Message tchat</label> :&nbsp;  <br /> <br />
							</td>
							<td>
								<input class="chat1" type="text" name="message" id="message" placeholder="Votre message" /> <br /> <br />
							</td>
						</tr>
						<br />
					</table>
					<div class="chatB">
						<input class="chat" type="submit" name="envoyer" value="Envoyer" onclick="refresh()" />
					</div>
				</p>
			</form>
			</div>
    </body>
</html>