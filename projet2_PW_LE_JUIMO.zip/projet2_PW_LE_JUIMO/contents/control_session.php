<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
	</head>
	
	<body background="contents2/fond1.jpg">
		<?php
			session_start();
			//si email ou nom utilisateur non identifié
			if(!isset($_SESSION['login']) || !isset($_SESSION['email']) || $_SESSION['login'] == '' || $_SESSION['email'] == '') {
				echo "<font size=\"+3\" color=\"yellow\"><p align=\"center\">Vous devez être <a href='/projet2_PW/PCHER_connexion.php'>connecter</a> à PCHER.</p></font>";
				exit();
			}
		?>
	</body>
</html>