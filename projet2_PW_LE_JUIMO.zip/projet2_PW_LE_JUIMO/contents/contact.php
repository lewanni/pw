<!DOCTYPE html>
<?php
	require('control_session.php');//vérifie si on est bien connecté
	
	if(isset($_POST['envoyer'])) { //test du bouton envoyer + traitement du bouton
		$nom = htmlspecialchars($_POST['nom']); //empêche de mettre du code html dans les champs texte
		$prenom = htmlspecialchars($_POST['prenom']);
		$sujet = htmlspecialchars($_POST['sujet']);
		$msg = htmlspecialchars($_POST['msg']);
		
		if(!empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['sujet']) && !empty($_POST['msg'])) { //vérification des champs complétés
			//paramètres d'encodage + envoi email
			$header1 = "MIME-Version: 1.0\r\n"; //version encodage du email
			$header1.= 'From:"'.$prenom.' '.$nom."<xxx@xxxx.fr>'.\"\n"; // adresse email expéditeur
			$header1.= 'Content-Type:text/html; charset="utf-8"'."\n"; //type d'encodage texte
			$header1.= 'Content-Transfer-Encoding: 8bit';
			//message à envoyer à l'auteur du site
			$message1 =' 
			<html>
				<body>
					MESSAGE CONTACT PCHER RECU. 
					<br /><br />
					Information du contact : <br />
					- Nom : '.$nom.'<br />- Prénom : 
					'.$prenom.'<br />- Sujet : 
					'.$sujet.'<br />- Message :<br />
					'.nl2br($msg).'
				</body>
			</html>
			';
			//message à envoyer : accusé de réception
			$header2 = "MIME-Version: 1.0\r\n"; //version encodage du email
			$header2.= 'From:"PCHER"<xxx@xxxx.fr>'."\n"; // adresse email expéditeur
			$header2.= 'Content-Type:text/html; charset="utf-8"'."\n"; //type d'encodage texte
			$header2.= 'Content-Transfer-Encoding: 8bit';
			
			$message2 =' 
			<html>
				<body>
					Bonjour, <br /><br />
					Nous vous confirmons que votre message a bien été envoyé à <b>PCHER</b>.
					 <br /><br />
					 Rappelle de vos coordonnée et du message envoyé : <br />
					 - Nom : '.$nom.'<br />- Prénom : '.$prenom.'
					 <br />- Sujet : '.$sujet.'
					 <br />- Message : <br />'.nl2br($msg).'
					 <br /><br />
					Nous espérons vous revoir bientôt.<br />
					<b>PCHER</b>
				</body>
			</html>
			';
			mail("quang532@gmail.com","CONTACT - PCHER", $message1, $header1); //fonction envoie email
			mail($_SESSION['email'],"Accusé de réception contact - PCHER", $message2, $header2); //fonction envoie email accusé reception
			
			echo "<script>alert(\"Votre message a bien été envoyé. Un e-mail de confirmation vous a été envoyer\");</script>";
			$error_ok = "Votre message a bien été envoyé !<br /><br />";
		} else 
			$error_ok = "Erreur : Tous Les champs doivent être compléter ! <br /><br />";
	}
?>

<html>
	
    <head>
        <title>Contact PCHER</title>
		<link rel="stylesheet" href="style2.css" />
		<meta charset="utf-8">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    </head>
	
    <body class="e">
		
        <h1>
			PCHER, LE SITE DES PRODUITS PAS CHER !
        </h1>
		<br />
		<nav>
            <ul>
                <li><a href="PCHER_accueil.php">Accueil</a></li>
                <li><a href="QuiSommeNous.php">Qui sommes-nous ?</a></li>
				<li><a href="chat.php">Salon de discussion</a></li>
                <li><a href="contact.php">Contact</a></li>
				 <li><a href="/projet2_PW/PCHER_deconnexion.php">Déconnexion</a></li>
            </ul>
        </nav>
		
		<div align="center">
			<h2> Entrez vos coordonnées et votre message pour nous contacter.</h2> <br /><br />
			
			<form action="" method="post">
				<table align="center">
					<tr>
						<td align="right">
							<label for="nom">Nom :&nbsp;</label>
						</td>
						<td>
							<input type="text" name="nom" id="nom" placeholder="Votre nom" value="<?php if(isset($nom)) echo $nom; ?>" /> <br /><br />
						<td>
					<tr/>
					<tr>
						<td align="right">
							<label for="prenom">Prénom :&nbsp;</label>
						</td>
						<td>
							<input type="text" name="prenom" id="prenom" placeholder="Votre prénom" value="<?php if(isset($prenom)) echo $prenom; ?>" /> <br /><br />
						<td>
					<tr/>
					<tr>
						<td align="right">
							<label for="sujet">Sujet :&nbsp;</label>
						</td>
						<td>
							<input type="text" name="sujet" id="sujet" placeholder="Votre sujet" value="<?php if(isset($sujet)) echo $sujet; ?>" /> <br /><br />
						<td>
					<tr/>
					<tr>
						<td align="right">
							<label for="message">Message :&nbsp;</label>
						</td>
						<td>
							<textarea rows="4" cols="50" name="msg" id="msg" placeholder="Entrez votre message içi..."></textarea>
						<td>
					<tr/>
				</table>
					<br />
				<input type="submit" name="envoyer" value="Envoyez le message"/>
				<br /><br />
			</form>
			<?php
				if(isset($error_ok))
					echo $error_ok;
			?>
		</div>
    </body>
</html>