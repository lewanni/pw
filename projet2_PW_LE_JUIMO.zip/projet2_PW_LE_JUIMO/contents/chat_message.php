<!DOCTYPE html>
<?php
	// création des messages du chat
	try {
		$bdd = new PDO('mysql:host=localhost;dbname=pcher;charset=utf8', 'root', '');
	} catch(Exception $e) {
		die('Erreur : '.$e->getMessage());
	}
	// Récupération les derniers messages jusqu'au 9999999999999 dernier message
	$reponse = $bdd->query('SELECT login, message, DATE_FORMAT(date, \'%d/%m/%Y %H:%i\') AS date1 FROM chat ORDER BY ID DESC LIMIT 0, 9999999999999');
	// Affichage de chaque message (données  protégées par htmlspecialchars)
	while ($donnees = $reponse->fetch())
		echo '<font color="red">['.$donnees['date1'].'] <strong>' . $donnees['login'] . ' :</strong></font>  <br />' . nl2br(htmlspecialchars($donnees['message'])) . '<br />';
	$reponse->closeCursor();
?>
