<!DOCTYPE html>
<?php
	require('control_session.php');//vérifie si on est bien connecté
	// création captcha
	require ('recaptchalib.php'); //librairie PHP par google
	$siteKey = '6Le29hQTAAAAAEdV6IB42k0zNG8vdjvICiVLfVWp'; // clé publique
	$secret = '6Le29hQTAAAAADHz5E6GWtQOp4y8iOqYGiJK7oCS'; //clé privée
?>
<html>

	<head>
		<title>
		Voiture Golf VII
		</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="style3.css" />
		<script src="https://www.google.com/recaptcha/api.js"></script>
	</head>
	
	<body>
		<h1>
			ACHAT Golf VII 1.6 TDi 90 ch A CONFIRMER
		</h1>
		
		<img class="i" src="contents2/golf11.jpg" alt="golf"/> 
		
		
		<h2>
			PRIX TTC : 3 000€
		</h2>
		
		<p>
			Pour connaître les détails du produit, <a class="achat" href="http://www.caradisiac.com/fiches-techniques/modele--volkswagen-golf-7/2015/vii+1.6+tdi+90+bluemotion+technology+5p/" title="Cliquez pour en savoir plus sur la Golf 7">cliquez ici</a>.
		</p>
		
		<p> 
			Entrez une adresse e-mail valide et validez le captcha :
			<form class="i" action="" method="POST">
				<input class="bouton" type="text" name="email" id ="email" placeholder="Votre adresse e-mail" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>" /> 
				<br />
				<div align="center" class="g-recaptcha" data-sitekey="<?php echo $siteKey; ?>"></div>
				<br />
				<input type="submit" name="acheter" value="Acheter !">
			</form>
		</p>
		<?php
			if(isset($_POST['acheter'])){
				$email = htmlspecialchars($_POST['email']);
				if(!empty($_POST['email'])) {
					if(filter_var($email, FILTER_VALIDATE_EMAIL)){ //si email ok
						$reCaptcha = new ReCaptcha($secret); //validation du formulaire pour savoir si on est humain ou robot
						if(isset($_POST["g-recaptcha-response"])) {
							$resp = $reCaptcha->verifyResponse($_SERVER["REMOTE_ADDR"], $_POST["g-recaptcha-response"]);
							if ($resp != null && $resp->success) { // si humain reconnu alors : envoie du mail
								$header = "MIME-Version: 1.0\r\n"; //version encodage du email
								$header.= 'From:"PCHER"<xxx@xxxx.fr>'."\n"; // adresse email expéditeur
								$header.= 'Content-Type:text/html; charset="utf-8"'."\n"; //type d'encodage texte
								$header.= 'Content-Transfer-Encoding: 8bit';
								//message à envoyer : port à changer 80 par défaut pour le lien cliquez içi
								$message =' 
								<html>
									<body>
											Bonjour, <br /><br />
											Nous vous confirmons que vous vous êtes bien fait avoir sur notre site <b>PCHER</b>.
											<br />
											Nous n\'avez pas de Golf VII à vendre.
											<br /><br />
											Nous espérons vous revoir bientôt. <br />
											<b>PCHER</b>
									</body>
								</html>
								';
								mail($email,"Confirmation achat Golf VII sur PCHER !", $message, $header); //fonction envoie email
								echo "
									<script>
										alert(\"Votre achat a bien été enregistré. Un e-mail de confirmation vient de vous être envoyé\");
										 window.location.replace('t.php');
									</script>"; //alerte de confirmation + redirection vers une autre page
							} else 
								echo "<p class=\"i\">Erreur : CAPTCHA incorrect ou non validé !</p>";
						}
					} else
						echo "<p class=\"i\">Erreur : Adresse e-mail incorrect !</p>";
				} else
					echo "<p class=\"i\">Erreur : Le champ adresse e-mail est vide !</p>";
			}
		?>
	</body>
</html>