<!DOCTYPE html>
<?php
	require('control_session.php');//vérifie si on est bien connecté
?>

<html>
	
    <head>
        <title>PCHER</title>
		<link rel="stylesheet" href="style2.css" />
		<meta charset="utf-8">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<style>
			h4 {
				margin:10px,10px,10px,10px;
			}
		</style>
    </head>
	
    <body class="q">
        <h1>
			PCHER, LE SITE DES PRODUITS PAS CHER !
        </h1>
		<br />
		<nav>
            <ul>
                <li><a href="PCHER_accueil.php">Accueil</a></li>
                <li><a href="QuiSommeNous.php">Qui sommes-nous ?</a></li>
				<li><a href="chat.php">Salon de discussion</a></li>
                <li><a href="contact.php">Contact</a></li>
				 <li><a href="/projet2_PW/PCHER_deconnexion.php">Déconnexion</a></li>
            </ul>
        </nav>
		
		<div style="height:267px;width:700px;background-color:#1E90FF;margin:auto;margin-left:325px;text-align:center;vertical-align: middle;display: inline-block;">
			<h4 style="font-size:10pt;color:white;font-weight: bold;display:inline-block;line-height:4em;vertical-align:middle;"> 
				Jeune plate-forme mondiale de produits pas chers sur internet sur Internet, PCHER est une place de marché composée uniquement de professionnels,
				tous passionnés, et via laquelle des millions de transactions ont lieu tous les jours récemment. Vous ne trouverez nul part ailleurs des prix défiant les notres, d'ailleurs si vous touvez un articles que nous vendons chez
				un autre vendeur à un prix plus bas que le notre nous vous donnons la somme de 100 euros et nous baissons directement le prix de cet article.
			</h4>
		</div>
		<br />
    </body>
	<br />
</html>