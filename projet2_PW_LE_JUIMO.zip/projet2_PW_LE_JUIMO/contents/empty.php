<!DOCTYPE html>
<?php
	require('control_session.php');
?>
<html>
	<head>
		<title>
			En construction
		</title>
		<script>
			alert("Page en construction");
		</script>
		<meta charset="utf-8">
		<link rel="stylesheet" href="style2.css" />
	</head>
	
	<body class="e">
		<h1>PAGE EN CONSTRUCTION</h1>
		<p>Revenez plus tard.
			<br><br>
		<a class="e" href="PCHER_accueil.php" title="Cliquez pour revenir à notre page d'acceuil">Revenir à la page d'accueil </a>
		</p>
		
	</body>
	
	
</html>